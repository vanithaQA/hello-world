package com.schedulemenow;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class BaseClass {
	public String baseURL = "https://www.uhhospitals.org/doctors";
	public static WebDriver driver;
	private static Logger logger = LogManager.getLogger(BaseClass.class);
	ExtentReports extent = new ExtentReports();
	ExtentSparkReporter spark = new ExtentSparkReporter("indexsmn.html");//html file will generated
		String projectpath = System.getProperty("user.dir");
					
		@Parameters("browserName")
			@BeforeClass
	public void setup(String browserName) {
	System.out.println("Browser Name is : "+browserName);
	System.out.println("Thread id : "+Thread.currentThread().getId());
	{
		if(browserName.equalsIgnoreCase("ie")) {
		System.setProperty("webdriver.ie.driver", "C:\\Users\\vnampel1-sa\\eclipse-workspace\\mavenregistrastion\\Drivers\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		logger.info("path setup completed");
		}
		
		else if (browserName.equalsIgnoreCase("firefox")) {
		System.setProperty("webdriver.gecko.driver","C:\\Users\\vnampel1-sa\\eclipse-workspace\\mavenregistrastion\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		logger.info("firefox opened");
		}

		else if(browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\nampellys\\git\\SmnProject\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();	
		}

		
		
		spark.config().setTheme(Theme.DARK);
		spark.config().setDocumentTitle("MyReport");
		spark.config().setReportName("Extent Report");
		extent.attachReporter(spark);
	}
	}
		/*
	 @AfterClass
	public void tearDown() {

	logger.info("window closed");
driver.quit();
extent.flush();
 }
 */
}

