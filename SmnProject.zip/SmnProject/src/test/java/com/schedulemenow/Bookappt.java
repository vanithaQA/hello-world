package com.schedulemenow;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

public class Bookappt extends BaseClass{

	
	private static Logger logger = LogManager.getLogger(ScheduleAnAppointment.class);
	@Test (priority=1)
	public void loginTest() throws InterruptedException {
		//Enter the Url
		driver.get("https://www.uhhospitals.org/doctors");
		driver.manage().window().maximize(); 
		logger.info("Url entered"); 
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		//Utility.captureScreenshot(driver, "Browser started");
		ExtentTest test =extent.createTest("URL entered");
		test.info("URL is loaded");
		test.pass("URL opened successfully");

		//Search for a provider by lastname
		WebElement username=driver.findElement(By.id("main-search"));
		js.executeScript("arguments[0].value='Veeravalli'",username);
		logger.info("Provider name entered successfully");
		ExtentTest test1 =extent.createTest("Provider name entered");
		test1.info("Value entered");
		test1.pass("Provider entered successfully");

		//Click action
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement searchbox=driver.findElement(By.xpath("//a[@class=\"UH-SearchResults-Refinements-Apply\"]"));
		js.executeScript("arguments[0].click()", searchbox);
		logger.info("provider appeared");
		ExtentTest test2 =extent.createTest("Click on the search button");
		test2.info("click on the button");
		test2.pass("Provider page opened successfully");

		//Click Schedule online button
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		WebElement scheduleonline=driver.findElement(By.xpath("//a[@class='UH-Feature-Doctors-DoctorSearchResults-Action-Button-Appt']"));
		js.executeScript("arguments[0].click()", scheduleonline);
		logger.info("Scheuled online button clicked");
		ExtentTest test3 =extent.createTest("Appointment scheduling page");
		test3.info("click on the scheduleonline");
		test3.pass("Appointment scheduling home page opened successfully");
	}
	@Test(priority=2)
	public void AppointmentScheduling() throws Exception {
		//select the state from drop down option
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement dropdownoption =(driver.findElement(By.xpath("//span[@class=\"k-select\"]")));
		js.executeScript("arguments[0].click()", dropdownoption);
		logger.info("clicked on the Choose an option dropdown");
		ExtentTest test1 =extent.createTest("selected dropdown");
		test1.info("Clickd on choose an option successfully");
	}
	@Test(priority=3)
	public void selectdropdownoption() {
		try {
			WebElement element = driver.findElement(By.xpath("//*[(text()='Myself [Must be 18+]')]"));
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", element);
			//System.out.println("Element clickable");
			logger.info("Selected the myself [Must be 18+] dropdownoption");
			ExtentTest test1 =extent.createTest("selected myself must be 18+");
			test1.info("selected myself must be 18+ option successfully");

		}catch(Exception element) {
			System.out.println("Element not clickeble");
			element.printStackTrace();
			System.out.println(element.getMessage());
		}
	}			
	@Test(priority=4)		
	private void SelectYEScheckbox() {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		/*
		WebElement checkbox = driver.findElement(By.xpath("/html/body/app-root/main/app-providers/section[3]/div/div[1]/div[2]/fieldset/label[1]"));
		js.executeScript("arguments[0].click()", checkbox);
		System.out.println("Yes button selected");
		logger.info("Selected the 'Yes' for have you seen this provider question");
		ExtentTest test1 =extent.createTest("Yes selected");
		test1.info("selected the yes option successfully");

		 */
		//select No option
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement Nobutton=driver.findElement(By.xpath("/html/body/app-root/main/app-providers/section[3]/div/div[1]/div[2]/fieldset/label[2]"));
		js.executeScript("arguments[0].click()", Nobutton);
		logger.info("No selected");
		ExtentTest test1 =extent.createTest("No selected");
		test1.info("selected the No option successfully");
	}
	@Test(priority=5)
	public void Typeofofficevisitdropdown()  {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement officevisit =(driver.findElement(By.xpath("//*[(text()='Choose an Option')]")));
		js.executeScript("arguments[0].click()", officevisit);
		logger.info("clicked on the type of office visit dropdown");
		ExtentTest test1 =extent.createTest("selected Type of office visit");
		test1.info("selected Type of office visit successfully");

	}
	@Test(priority=6)
	public void Followupvisit() {
		try {
			WebElement Followupvisit = driver.findElement(By.xpath("//*[(text()='New Patient Visit')]"));
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", Followupvisit);
			System.out.println("New Patient Visit selected");
			logger.info("Selected the Followup visit dropdownoption");
			ExtentTest test1 =extent.createTest("New Patient Visit selected");
			test1.info("New Patient Visit selectedsuccessfully");
		}
		catch(Exception Followupvisit) {
			System.out.println("Element not clickeble");
			Followupvisit.printStackTrace();
			System.out.println(Followupvisit.getMessage());
		}
	}
	@Test(priority=7)
	public void Reasonforvisit() {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			WebElement Enterreasonforvisit=driver.findElement(By.xpath("//input[@class=\"k-input\"]"));
			JavascriptExecutor js=(JavascriptExecutor)driver;
			Actions act=new Actions(driver);
			js.executeScript("arguments[0].value='checkup'", Enterreasonforvisit);
			//Actions act=new Actions(driver);
			//act.sendKeys(Keys.ENTER).perform();
			js.executeScript("arguments[0].click()", Enterreasonforvisit);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);

			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			logger.info("Reason entered successfully");
			ExtentTest test =extent.createTest("Reasonforvisit");
			test.info("Reason entered");
			//test1.pass("Reason entered successfully");

			System.out.println("Key board pressed successfully");
		}

		catch(Exception Enterreasonforvisit) {
			System.out.println("Element not clickeble");
			Enterreasonforvisit.printStackTrace();
			System.out.println(Enterreasonforvisit.getMessage());
		}
	}
	@Test(priority=8)
	public void SelectScheduleAvailability() {
		//String dropdown="WED";
		//WebElement element = driver.findElement(By.xpath("//*[(text()='"+dropdown+"')]"));
		/*
		//Click on the moretime button
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement Clickonmoretime = driver.findElement(By.xpath("/html/body/app-root/main/app-providers/section[5]/div/div/div[3]/div[5]/div[6]/div"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			js.executeScript("arguments[0].click()", Clickonmoretime);
		 */
		//select Time			
		WebElement scheduleavailability = driver.findElement(By.xpath("//*[@id=\"SRN|SUBURBAN10|PRIMARY|NPV|VEERAVALLI|4/29/2021 8:15:00 AM|4/29/2021 8:45:00 AM\"]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", scheduleavailability);
		logger.info("appointment time selcted successfully");
		ExtentTest test =extent.createTest("availability selected");
		test.info("appointment time selcted successfully");
	}

	//Login with existing user credentials

	@Test(priority=9)
	public void loginwithexistinguser() {
		WebElement Enterusername = driver.findElement(By.xpath("//*[@id=\"username\"]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].value='Mcreekmore'", Enterusername);
		logger.info("Enter the username");
		ExtentTest test1 =extent.createTest("Username entered successfully");

	}
	@Test(priority=10)
	public void Enterpassword() {
		WebElement Enterpassword = driver.findElement(By.xpath("/html/body/app-root/main/app-login/div/div/div/section[2]/div[5]/input"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].value='test@123'", Enterpassword);
		logger.info("Enter the password");
		ExtentTest test2 =extent.createTest("Password entered successfully");
		test2.info("Password entered");
	}

	@Test(priority=11)
	public void Clickontheloginbutton() {
		//JavascriptExecutor js=(JavascriptExecutor)driver;
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement Clickonloginbutton= driver.findElement(By.xpath("/html/body/app-root/main/app-login/div/div/div/section[2]/div[6]/div[1]/button"));
		Clickonloginbutton.click();
		//js.executeScript("arguments[0].click()", Clickonloginbutton);
		logger.info("Click on the login button");
		ExtentTest test =extent.createTest("User Logged in successfully");
		test.info("User Logged in successfully");

	}
	//Skip insurance page
	@Test(priority=12)
	public void Skipinsurancepage() {
		WebElement Skipinsurance= driver.findElement(By.xpath("//*[(text()='Skip This Form')]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", Skipinsurance);
		logger.info("Skipped the insurance page");
		ExtentTest test =extent.createTest("Skipped the insurance page successfully");
		test.info("Skipped insurance");

	}
	@Test(priority=13)
	public void Confirmappointment() {
		WebElement Skipinsurance= driver.findElement(By.xpath("//*[(text()='Confirm Appointment')]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", Skipinsurance);
		logger.info("ConfirmAppointment");
		ExtentTest test =extent.createTest("Appointment confirmed successfully");
	test.info("Sheduled the appointment");


	}
}
