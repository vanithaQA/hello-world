package com.schedulemenow;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;

public class ScheduleAnAppointment extends BaseClass{
	//WebDriver driver;
	//	public void ElementActions(WebDriver driver) {
	//		this.driver = driver;
	//	}
	By dropdown = By.xpath("//*[@id='navbar']/div[2]/div/div/div[1]/button");
	private static Logger logger = LogManager.getLogger(ScheduleAnAppointment.class);
	@Test (priority=1)
	public void schedulemenowthroughguest() throws InterruptedException {
		//Enter the Url
		driver.get("https://www.uhhospitals.org/doctors");
		driver.manage().window().maximize(); 
		driver.manage().deleteAllCookies();
		logger.info("Url entered"); 
		JavascriptExecutor js=(JavascriptExecutor)driver;
		ExtentTest test =extent.createTest("URL entered successfully");
		test.info("URL is loaded");
		test.pass("URL opened successfully");

		//Search for a provider by lastname
		WebElement username=driver.findElement(By.id("main-search"));
		js.executeScript("arguments[0].value='Veeravalli'",username);
		logger.info("Provider name entered successfully");
		ExtentTest test1 =extent.createTest("Provider name entered");
		test1.info("Value entered");
		test1.pass("Provider entered successfully");

		//Click action
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement searchbox=driver.findElement(By.xpath("//a[@class=\"UH-SearchResults-Refinements-Apply\"]"));
		js.executeScript("arguments[0].click()", searchbox);
		logger.info("provider appeared");
		ExtentTest test2 =extent.createTest("Click on the search button");
		test2.info("click on the button");
		test2.pass("Provider page opened successfully");

		//Click Schedule online button
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement scheduleonline=driver.findElement(By.xpath("//a[@class='UH-Feature-Doctors-DoctorSearchResults-Action-Button-Appt']"));
		js.executeScript("arguments[0].click()", scheduleonline);
		logger.info("Scheuled online button clicked");
		ExtentTest test3 =extent.createTest("Appointment scheduling page");
		test3.info("click on the scheduleonline");
		test3.pass("Appointment scheduling home page opened successfully");
	}
	@Test(priority=2)
	public void Choosedropdownoption() throws Exception {
		//select the state from drop down option
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement dropdownoption =(driver.findElement(By.xpath("//span[@class=\"k-select\"]")));
		js.executeScript("arguments[0].click()", dropdownoption);
		logger.info("clicked on the Choose an option dropdown");
		ExtentTest test1 =extent.createTest("selected dropdown");
		test1.info("Clickd on choose an option successfully");

	}
	@Test(priority=3)
	public void selectdropdownoption() {

		try {

			WebElement element = driver.findElement(By.xpath("//*[(text()='Myself [Must be 18+]')]"));
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", element);
			//String dropdown="Myself [Must be 18+]";
			//WebElement element1 = driver.findElement(By.xpath("//*[(text()='"+dropdown+"')]"));
			logger.info("Selected the myself [Must be 18+] dropdownoption");
			ExtentTest test1 =extent.createTest("selected myself must be 18+");
			test1.info("selected myself must be 18+ option successfully");

		}catch(Exception element) {
			System.out.println("Element not clickeble");
			element.printStackTrace();
			System.out.println(element.getMessage());
		}
	}			
	@Test(priority=4)		
	public void SelectNocheckbox() {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		/*
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement checkbox = driver.findElement(By.xpath("/html/body/app-root/main/app-providers/section[3]/div/div[1]/div[2]/fieldset/label[1]"));
		js.executeScript("arguments[0].click()", checkbox);
		System.out.println("Yes button selected");
		logger.info("Selected the 'Yes' for have you seen this provider question");
		ExtentTest test1 =extent.createTest("Yes selected");
		test1.info("selected the yes option successfully");


	}
	*/
	//select No option
	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	WebElement Nobutton=driver.findElement(By.xpath("/html/body/app-root/main/app-providers/section[3]/div/div[1]/div[2]/fieldset/label[2]"));
	js.executeScript("arguments[0].click()", Nobutton);
logger.info("No selected");
ExtentTest test1 =extent.createTest("No selected");
test1.info("selected the No option successfully");
}
	@Test(priority=5)
	public void Typeofofficevisitdropdown()  {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement officevisit =(driver.findElement(By.xpath("//*[(text()='Choose an Option')]")));
		js.executeScript("arguments[0].click()", officevisit);
		logger.info("clicked on the type of office visit dropdown");
		ExtentTest test1 =extent.createTest("selected Type of office visit");
		test1.info("selected Type of office visit successfully");

	}
	@Test(priority=6)
	public void Newpatienvisit() {
		try {
			/*
			WebElement Followupvisit = driver.findElement(By.xpath("//*[(text()='Follow Up Visit')]"));
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", Followupvisit);
			System.out.println("Followup selected");
			logger.info("Selected the Followup visit dropdownoption");
			ExtentTest test1 =extent.createTest("Followup visit selected");
			test1.info("Followup visit selectedsuccessfully");
		}
		*/
		WebElement Newpatientvisit = driver.findElement(By.xpath("//*[(text()='New Patient Visit')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", Newpatientvisit);
		logger.info("Selected the Followup visit dropdownoption");
		ExtentTest test1 =extent.createTest("New Patient Visit selected");
		test1.info("New Patient Visit selectedsuccessfully");
		}
		catch(Exception Followupvisit) {
			System.out.println("Element not clickeble");
			Followupvisit.printStackTrace();
			System.out.println(Followupvisit.getMessage());
		}
	}
	@Test(priority=7)
	public void Reasonforvisit() {
		try {
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement Enterreasonforvisit=driver.findElement(By.xpath("//input[@class=\"k-input\"]"));
			JavascriptExecutor js=(JavascriptExecutor)driver;
			//Actions act=new Actions(driver);
			js.executeScript("arguments[0].value='checkup'", Enterreasonforvisit);
			//Actions act=new Actions(driver);
			//act.sendKeys(Keys.ENTER).perform();
			js.executeScript("arguments[0].click()", Enterreasonforvisit);
			
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);

			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			logger.info("Reason entered successfully");
			ExtentTest test =extent.createTest("Reasonforvisit");
			test.info("Reason entered");
			//test1.pass("Reason entered successfully");

			System.out.println("Key board pressed successfully");
		}

		catch(Exception Enterreasonforvisit) {
			System.out.println("Element not clickeble");
			Enterreasonforvisit.printStackTrace();
			System.out.println(Enterreasonforvisit.getMessage());
		}
	}
	
	@Test(priority=8)
	public void SelectScheduleAvailability() {
		//String dropdown="WED";
		//WebElement element = driver.findElement(By.xpath("//*[(text()='"+dropdown+"')]"));
		/*
		//Click on the moretime button
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement Clickonmoretime = driver.findElement(By.xpath("/html/body/app-root/main/app-providers/section[5]/div/div/div[3]/div[5]/div[6]/div"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			js.executeScript("arguments[0].click()", Clickonmoretime);
		 */
		//select Time			
		//WebElement ele= driver.findElement(By.xpath("//*[@class='row calendar-week'][2]/div")); 
				////List<WebElement> objcol = ele.findElements(By.tagName("div"));
				//System.out.println(ele.getTagName());
		
		//WebElement scheduleavailability = driver.findElement(By.xpath("//*[@id=\"SRN|SUBURBAN10|PRIMARY|VIRNPVHOME|VEERAVALLI|6/8/2021 9:15:00 AM|6/8/2021 9:45:00 AM\"]/div"));
//List <WebElement> element =	driver.findElements(By.xpath("/html/body/app-root/main/app-providers/section[5]/div/div/div[2]/div/div[3]"));
		//element.findElement(By.tagName("div _ngcontent-mqu-c1"));
	
		
WebElement webtable = driver.findElement(By.xpath("/html/body/app-root/main/app-providers/section[5]/div/div/div[2]/div/div[3]"));
        
        //Get rows which has data
        List<WebElement> rowsWithData = webtable.findElements(By.tagName("div _ngcontent-mqu-c1"));
        System.out.println(rowsWithData.size());
       
        /*
        //Print the whole web table
        System.out.println("Table Data is: ");
        for(int rowIndex =0; rowIndex<rowsWithData.size(); rowIndex++) {
         System.out.println("Data of Row " + (rowIndex+1) + " is:");
         List<WebElement> colsWithData = rowsWithData.get(rowIndex).findElements(By.xpath(".//div[@class='rt-td'][text()]"));
         for(int colIndex =0; colIndex<colsWithData.size(); colIndex++)
         System.out.println("Data at Cell with Row "+ (rowIndex+1) + " Column " + (colIndex+1) + " : "+ colsWithData.get(colIndex).getText());
       */
        }
		
		
		
		
		
		
		
		
		
		/*
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//JavascriptExecutor js=(JavascriptExecutor)driver;
		//js.executeScript("arguments[0].click()", scheduleavailability);
		logger.info("appointment time selcted successfully");
		ExtentTest test =extent.createTest("availability selected");
		test.info("appointment time selected successfully");
	}
*/
	//Checkout as guest
	@Test(priority=9)
	public void checkoutasguest() throws InterruptedException {
		Thread.sleep(5000);
		WebElement guestcheckout = driver.findElement(By.xpath("//*[@class=\"ghost-button submit-button\"]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", guestcheckout);
		logger.info("Click on the Booknow button");
		ExtentTest test =extent.createTest("Selected guest checkout successfully");
		test.info("Selected guest checkout successfully");
	}
	@Test(priority=10)
	public void Enterfirstname() throws AWTException {
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 WebElement firstname=driver.findElement(By.id("FirstName"));
		 firstname.sendKeys("Rita");
		 //JavascriptExecutor js=(JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value='Diya'", firstname);
		ExtentTest test =extent.createTest("firstname entered successfully");
		logger.info("Enter the firstname");
		test.info("firstname entered successfully");
	}
	@Test(priority=11)
	public void Enterlastname() {
	 driver.findElement(By.id("LastName")).sendKeys("automationTest");;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//JavascriptExecutor js=(JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value='Test'", lastname);
		ExtentTest test =extent.createTest("lastname entered successfully");
		logger.info("Enter the lastname");
		test.info("firstname entered successfully");
	}
	@Test(priority=12)
	public void Enterdateofbirth() {
		
		try {
			JavascriptExecutor js=(JavascriptExecutor)driver;	
		WebElement dateofbirth=driver.findElement(By.xpath("//*[@id='DateBirth']/span/kendo-dateinput/span/input"));
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		dateofbirth.click();
//		dateofbirth.sendKeys("02-02-2000");
//		dateofbirth.sendKeys(Keys.TAB);
		
		js.executeScript("arguments[0].click()", dateofbirth);
		js.executeScript("arguments[0].value='02-05-1987'",dateofbirth);
		logger.info("dateofbirth entered");
		ExtentTest test4 =extent.createTest("Smn Test");
		test4.pass("enter date of birth");
		test4.info("dateofbirth entered successfully");
		}
		catch(Exception e) {
			e.printStackTrace();
}
		/*
		WebElement date=driver.findElement(By.xpath("/html/body/app-root/kendo-popup/div/kendo-calendar/kendo-calendar-viewlist/kendo-virtualization/table/tbody[2]/tr[3]/td[1]/span"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//js.executeScript("arguments[0].value='02-02-2000'", date);
		js.executeScript("arguments[0].click()", dateofbirth);
		logger.info("dateofbirth entered");
		System.out.println("Date entered correctly");
		*/
	}
	
	@Test(priority=13)
	public void selectgender() {
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement gender=driver.findElement(By.xpath("/html/body/app-root/main/app-createaccount/form/section[1]/div/div[2]/div[2]/div/label[1]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		js.executeScript("arguments[0].click()", gender);
		logger.info("gender selected");
		ExtentTest test3 =extent.createTest("select female gender");
		test3.pass("select gender");
		test3.info("gender selected successfully");
	}
	@Test(priority=13)
	public void enteraddress() {
		//JavascriptExecutor js=(JavascriptExecutor)driver;
	driver.findElement(By.id("Street")).sendKeys("123 Treat Rd");;
		//address.sendKeys("123 Treat Rd");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//js.executeScript("arguments[0].value='123 Treat Rd'",address);
		logger.info("address entered");
		ExtentTest test7 =extent.createTest("Enter the address");
		test7.pass("Enter the address");
		test7.info("address entered successfully");
	}
	@Test(priority=14)
	//Enter the city 
	public void Entercity() {
		//JavascriptExecutor js=(JavascriptExecutor)driver;
		driver.findElement(By.xpath("//*[@id=\"City\"]")).sendKeys("Aurora");;
		//city.sendKeys("Aurora");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//js.executeScript("arguments[0].value='Aurora'",city);
		logger.info("city entered");
		ExtentTest test8 =extent.createTest("Enter cityname");
		test8.pass("Enter the city name");
		test8.info("city name entered successfully");
	}
	/*
	@Test(priority=16)
	//select the state from drop down option
	public void dropdownstate() {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement element=driver.findElement(By.xpath("//*[@id=\"k-ca6d83dd-8525-4cd6-993e-e46fea9886a6\"]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		js.executeScript("arguments[0].value='ohio'",element);
		Select sel = new Select (element);
		sel.selectByValue("OH");
		logger.info("state selected from dropdown");
		ExtentTest test10 =extent.createTest("SMN Test");
		test10.pass("select the state");
		test10.info("state selected successfully");

	}
	*/
	@Test(priority=15)
	public void Zipcode() {
		//JavascriptExecutor js=(JavascriptExecutor)driver;
		driver.findElement(By.id("ZipCode")).sendKeys("44202");
		//zipcode.sendKeys("44202");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//js.executeScript("arguments[0].value='44202'",zipcode);
		logger.info("zipcode entered");
		ExtentTest test9 =extent.createTest("Enter the zipcode");
		test9.pass("Enter the zipcode");
		test9.info("zipcode entered successfully");
	}

	//Enter the email address 
	@Test(priority=16)
	public void Emailaddress() {
		//JavascriptExecutor js=(JavascriptExecutor)driver;
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("uh@uh.com");
		//email.sendKeys("uh@uh.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//js.executeScript("arguments[0].value='uh@uh.com'",email);
		logger.info("emailaddress entered");
		ExtentTest test6 =extent.createTest("Registration Test");
		test6.pass("Enter emailaddress");
		test6.info("email address entered successfully");

	}

	//Enter the phone number
	@Test(priority=17)
	public void Phonenumber() throws InterruptedException, AWTException {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement phonenumber=driver.findElement(By.className("k-textbox"));
		//phonenumber.sendKeys("330-222-1111");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		js.executeScript("arguments[0].value='330-222-1111'",phonenumber);
		phonenumber.clear();
		phonenumber.sendKeys("330-222-1111");
		
		Thread.sleep(3000);
		Robot robot=new Robot();
		robot.keyPress(KeyEvent.VK_SPACE);
		robot.keyRelease(KeyEvent.VK_SPACE);
		robot.keyPress(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_S);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyRelease(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_N);
		robot.keyRelease(KeyEvent.VK_N);
		robot.keyPress(KeyEvent.VK_D);
		robot.keyRelease(KeyEvent.VK_D);
		
	
		
		
		logger.info("phonenumber entered");
		ExtentTest test5 =extent.createTest("Enter the phonenumber");
		test5.pass("Enter the phonenumber");
		test5.info("phonenuber entered successfully");

	}
	@Test(priority=18)	
	public void selectradiobutton() {
		WebElement termsandconditions = driver.findElement(By.xpath("/html/body/app-root/main/app-createaccount/form/section[2]/div/div[1]/div/label[1]/label"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", termsandconditions);
		logger.info("click on terms and condition radio button");
		ExtentTest test =extent.createTest("Radio button selected");
		test.info("click on terms and condition radio button");
		
	}
	
	@Test(priority=20)
	public void Clickcontinue() {
		WebElement Clickoncontinue = driver.findElement(By.xpath("//*[@class='submit-button']"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		
		js.executeScript("arguments[0].click()", Clickoncontinue);
		logger.info("Cliked on continue button");
		ExtentTest test =extent.createTest("patient information saved successfully");
		test.info("Cliked on continue button");
		
	}
	
	@Test(priority=21)
	public void Selectverifiedaddress() {
		WebElement verifiedaddress = driver.findElement(By.xpath("//*[(text()='Use Verified Address : 123 Treat Rd  Aurora, OH 44202')]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", verifiedaddress);
		logger.info("Cliked on continue button");
		ExtentTest test =extent.createTest("verifeid address selected");
		test.info("Verified address selected succesfully");
			
	}
	@Test(priority=22)
	public void Clickoncontinuebutton() {
		WebElement Clickoncontinue = driver.findElement(By.xpath("//*[@class=\"submit-button mt-3\"]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()",  Clickoncontinue);
		logger.info("Cliked on continue button");
		ExtentTest test =extent.createTest("selected verified address");
		test.info("verified address passed");
				
	}
	
	@Test(priority=23)
	public void Skipinsurancepage() {
		WebElement Skipinsurance= driver.findElement(By.xpath("//*[(text()='Skip This Form')]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", Skipinsurance);
		logger.info("Skip the insurance page");
		ExtentTest test =extent.createTest("Insurance page skipped successfully");
		test.info("Insurance page skipped successfully");

	}
	
	/*

	@Test(priority=24)
	public void Confirmappointment() {
		WebElement Confirmappointment= driver.findElement(By.xpath("//*[(text()='Confirm Appointment')]"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", Confirmappointment);
		logger.info("Click on the confrimappointment button");
		ExtentTest test =extent.createTest("Appointment confirmed successfully");
		test.info("Appointment confirmed successfully");

	}
	*/
}





































